package org.example.kimia300384851;


import org.example.kimia300384851.model.SeatReservation;
import org.example.kimia300384851.repository.SeatReservationRepository;
import org.example.kimia300384851.service.SeatReservationService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

@RunWith(MockitoJUnitRunner.class)
@ExtendWith(MockitoExtension.class)


public class SeatReservationServiceTest {
    @InjectMocks
    private SeatReservationService seatReservationService;

    @Mock
    private SeatReservationRepository seatReservationRepository;

    @Test
    public void testGetAllReservations() {

        List<SeatReservation> mockReservations = Arrays.asList(
                new SeatReservation(1L, "A1", "John Doe", LocalDate.now()),
                new SeatReservation(2L, "B2", "Jane Doe", LocalDate.now())
        );

        Mockito.when(seatReservationRepository.findAll()).thenReturn(mockReservations);


        List<SeatReservation> reservations = seatReservationService.getAllReservations();


        assertEquals(2, reservations.size());
        assertEquals("A1", reservations.get(0).getSeatCode());
        assertEquals("John Doe", reservations.get(0).getCustomerName());
    }


    @Test
    public void testUpdateReservation() {

        SeatReservation existingReservation = new SeatReservation(1L, "A1", "John Doe", LocalDate.now());
        Mockito.when(seatReservationRepository.findById(1L)).thenReturn(Optional.of(existingReservation));

        SeatReservation updatedReservation = new SeatReservation(1L, "A1", "Jane Doe", LocalDate.now());
        Mockito.when(seatReservationRepository.save(updatedReservation)).thenReturn(updatedReservation);


        SeatReservation result = seatReservationService.updateReservation(updatedReservation);


        assertEquals("Jane Doe", result.getCustomerName());
    }


    @Test
    public void testDeleteReservationById() {

        Long reservationId = 1L;


        seatReservationService.deleteReservationById(reservationId);


        Mockito.verify(seatReservationRepository, Mockito.times(1)).deleteById(reservationId);
    }


    @Test
    public void testIsSeatReserved() {

        SeatReservation existingReservation = new SeatReservation(1L, "A1", "John Doe", LocalDate.now());
        Mockito.when(seatReservationRepository.findBySeatCode("A1")).thenReturn(Optional.of(existingReservation));


        boolean isReserved = seatReservationService.isSeatReserved("A1");


        assertTrue(isReserved);
    }
}
