package org.example.kimia300384851.service;


import org.example.kimia300384851.model.SeatReservation;
import org.example.kimia300384851.repository.SeatReservationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class SeatReservationService {

    @Autowired
    private SeatReservationRepository seatReservationRepository;

    // Save new seat ()
    public SeatReservation saveReservation(SeatReservation reservation) {
        return seatReservationRepository.save(reservation);
    }

    // display saved information
    public List<SeatReservation> getAllReservations() {
        return seatReservationRepository.findAll();
    }

    // reservation by ID
    public SeatReservation getReservationById(Long id) {
        Optional<SeatReservation> optional = seatReservationRepository.findById(id);
        return optional.orElseThrow(() -> new RuntimeException("Reservation not found for id: " + id));
    }

    //Update existing data
    public SeatReservation updateReservation(SeatReservation reservation) {
        return seatReservationRepository.save(reservation);
    }

    // Delete by ID
    public void deleteReservationById(Long id) {
        seatReservationRepository.deleteById(id);
    }

    // return true if seat is already chosen
    public boolean isSeatReserved(String seatCode) {
        return seatReservationRepository.findBySeatCode(seatCode).isPresent();
    }
}
