package org.example.kimia300384851.controller;


import org.example.kimia300384851.model.SeatReservation;
import org.example.kimia300384851.service.SeatReservationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class SeatReservationController {
    @Autowired
    private SeatReservationService service;

    @GetMapping("/")
    public String viewHomePage(Model model) {
        model.addAttribute("listReservations", service.getAllReservations());
        model.addAttribute("remainingSeats", 20 - service.getAllReservations().size()); // Assuming 20 seats available and by each reserved it should decrease
        return "index";
    }

    @PostMapping("/saveReservation")
    public String saveReservation(@ModelAttribute("reservation") SeatReservation reservation, Model model) {
        // Check if the seat is already reserved ,but it does not work
        if (service.isSeatReserved(reservation.getSeatCode())) {
            model.addAttribute("errorMessage", "The seat is already taken");
            model.addAttribute("reservation", reservation);
            return "index";
        }
        // Validate seat code format: must be A-E followed by a number (e.g., A1, B2, etc.)
        String seatCodePattern = "^[A-E][1-9]$";
        if (!reservation.getSeatCode().matches(seatCodePattern)) {
            model.addAttribute("errorMessage", "Please follow the seat code format: A1, B2, etc.");
            model.addAttribute("reservation", reservation);
            return "index";
        }

        // after validation the method save correctly
        service.saveReservation(reservation);
        return "redirect:/";
    }



        @GetMapping("/showFormForUpdate/{id}")
    public String showFormForUpdate(@PathVariable(value = "id") long id, Model model) {
           //find by id
            SeatReservation reservation = service.getReservationById(id);


            if (reservation == null) {
                throw new RuntimeException("Reservation not found for id: " + id);
            }


            model.addAttribute("reservation", reservation);

           //return to edit page
            return "edit";

    }

    @PostMapping("/updateReservation")
    public String updateReservation(@ModelAttribute("reservation") SeatReservation reservation) {
        // Update the reservation in the database
        service.updateReservation(reservation);

        // Redirect to the main page.
        return "redirect:/";
    }


    @GetMapping("/deleteReservation/{id}")
    public String deleteReservation(@PathVariable(value = "id") long id) {
        service.deleteReservationById(id);
        return "redirect:/";
    }
}
