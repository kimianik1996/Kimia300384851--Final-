package org.example.kimia300384851;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Kimia300384851ApplicationTests {

    @Test
    void contextLoads() {
    }

}
