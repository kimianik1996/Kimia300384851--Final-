package org.example.kimia300384851.repository;


import org.example.kimia300384851.model.SeatReservation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;
//interface repositoiry is my superclass and parent class of seat reservation class in model package
@Repository
public interface SeatReservationRepository extends JpaRepository<SeatReservation, Long> {

    Optional<SeatReservation> findBySeatCode(String seatCode);
}
