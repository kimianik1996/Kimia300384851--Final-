package org.example.kimia300384851;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Kimia300384851Application {

    public static void main(String[] args) {
        SpringApplication.run(Kimia300384851Application.class, args);
    }

}
